const display = document.getElementById("display");
const historyList = document.getElementById("history-list");
const calculator = document.querySelector(".calculator");

function append(value) {
  display.value += value;
}

function clearDisplay() {
  display.value = "";
}

function calculate() {
  try {
    const result = eval(display.value);
    addToHistory(`${display.value} = ${result}`);
    display.value = result;
  } catch {
    display.value = "Error";
  }
}

function addToHistory(entry) {
  const li = document.createElement("li");
  li.textContent = entry;
  historyList.prepend(li);
}

function toggleTheme() {
  calculator.classList.toggle("dark");
  const isDark = calculator.classList.contains("dark");
  document.body.classList.toggle("dark", isDark);
  const themeBtn = document.querySelector(".theme-grid-btn");
  themeBtn.textContent = isDark ? "🌞" : "🌙";
}
